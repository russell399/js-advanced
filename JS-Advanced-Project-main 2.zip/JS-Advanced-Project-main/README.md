# JS-Advanced-Russell-Perez

# Informazioni
Ho riscontrato delle difficoltà durante la realizzazione del progetto (In particolare nell'implementazione dell'API KEY che permette il corretto funzionamento dell'app) infatti quest'ultimo non risulta completo.
Analizziamo il processo di realizzazione:

1) creazione ambiente di lavoro mediante CLIL (V)
2) chiamata all'api e implementazione all'interno dei file (X non riuscito)
3) elaborazione dei dati e visualizzazione dei dati (V)
4) Interfaccia grafica minimal realizzata mediante HTML e CSS (V)
5) gestione degli errori (in teoria riuscita, ma non verificabile attualmente)
6) demo in netlify (riuscita ma non funzionante )


# Demo WEB APP
https://js-advanced-russell-perez.netlify.app
